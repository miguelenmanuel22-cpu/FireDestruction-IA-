# FeDestruction IA

Asistente local de scripts FE para Roblox con cyber-nuclear UI.

## Construir el APK automáticamente
Sube este repo a GitHub. GitHub Actions compilará el APK solo en ~25 min.
1. Ve a la pestaña **Actions** del repo
2. Espera el ✅ verde (build-apk)
3. Descarga **FeDestructionIA-APK** desde Artifacts

## Probar en navegador
```
cd FeDestruction_IA
python3 launcher.py
```
Abre http://localhost:5000

## Estructura
- FeDestruction_IA/ - App web (HTML/CSS/JS)
- FeDestruction_IA/android/ - Config Android (Buildozer)
- .github/workflows/build-apk.yml - Compilador automático
