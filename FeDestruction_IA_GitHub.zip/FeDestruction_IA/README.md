# ☢ FeDestruction IA - v1.0 OfEnd Edition

**Asistente local para scripts FE de Roblox**
Una réplica funcional especializada en generar scripts de destrucción masiva
para Roblox v2.717.985 (22 Abril 2026).

---

## 🎯 Características

- ✅ **2 Modos:** Script (generador FE) y Original (chat general)
- ✅ **GUI cyber-nuclear:** fondo animado, naranja+verde, partículas
- ✅ **Plantillas pre-cargadas:** fly, noclip, nuke, kill aura, GUI, scanner, anti-byfron, etc.
- ✅ **API opcional:** conecta OpenAI/Anthropic para respuestas con IA real
- ✅ **Funciona OFFLINE** (sin internet) usando conocimiento local
- ✅ **Multi-plataforma:** Windows (.exe), Linux/Mac (binario), Android (.apk), navegador
- ✅ **Responsive:** se adapta a móvil/tablet/PC
- ✅ **localStorage:** guarda tu API key solo en tu dispositivo

---

## 📦 Estructura del proyecto

```
FeDestruction_IA/
├── index.html              # App principal (HTML5)
├── style.css               # Tema cyber-nuclear
├── app.js                  # Lógica del chatbot
├── knowledge_base.js       # Plantillas + conocimiento
├── launcher.py             # Servidor local (PC)
├── build_exe.bat           # Build .exe para Windows
├── build_exe.sh            # Build binario para Linux/Mac
├── android/
│   ├── main.py             # Versión Kivy/WebView
│   └── buildozer.spec      # Config para construir APK
└── README.md               # Esta documentación
```

---

## 🚀 Instalación rápida

### Opción 1: Solo navegador (más simple)
```
1. Abre index.html con cualquier navegador moderno
2. ¡Listo! Funciona sin instalación
```

### Opción 2: Servidor local con Python
```bash
python3 launcher.py
# Abre automáticamente en tu navegador en http://127.0.0.1:8765
```

### Opción 3: Compilar a .exe (Windows)
```bat
build_exe.bat
# El .exe quedará en: dist/FeDestructionIA.exe
```

### Opción 4: Compilar a binario (Linux/Mac)
```bash
chmod +x build_exe.sh
./build_exe.sh
# El binario quedará en: dist/FeDestructionIA
```

### Opción 5: Compilar APK Android
```bash
# Requiere Linux + Java JDK + Android SDK + Buildozer
cd android
cp ../index.html ../style.css ../app.js ../knowledge_base.js .
pip install buildozer
buildozer android debug
# El APK quedará en: bin/fedestructionia-1.0-debug.apk
```

---

## 💡 Uso del chatbot

### Comandos básicos

| Comando | Descripción |
|---------|-------------|
| `ayuda` | Muestra todos los comandos |
| `plantilla [nombre]` | Muestra plantilla de script |
| `lista [categoría]` | Lista scripts por categoría |
| `crear [cosa]` | Sinónimo de plantilla |

### Plantillas disponibles

| Plantilla | Descripción |
|-----------|-------------|
| `loader` | Loader modular FE desde GitHub |
| `fly` | Vuelo FE con BodyVelocity |
| `noclip` | Atravesar paredes |
| `nuke` | Explosión nuclear masiva |
| `killaura` | Kill aura automático |
| `speed` | Speed boost |
| `godmode` | HP infinito |
| `teleport` | Teleport a click |
| `guicircular` | Botón circular draggable |
| `remotescanner` | Scanner de remotes |
| `antibyfron` | Heartbeat de evasión |
| `cloak_thread` | Ocultar funciones |

### Categorías para `lista`
- `lista exploits` — todos los exploits
- `lista funciones` — funciones básicas (fly, noclip, etc.)
- `lista gui` — interfaces gráficas
- `lista executors` — ranking de executors

---

## 🤖 Conectar IA real (opcional)

Por defecto la app usa solo el conocimiento local pre-cargado. Para
respuestas inteligentes con una IA real:

1. Click en el botón **⚙ API** (esquina superior derecha)
2. Selecciona el proveedor: **OpenAI** o **Anthropic**
3. Pega tu API key (se guarda solo en tu navegador)
4. Opcional: especifica un modelo (default: `gpt-4o-mini` / `claude-3-5-sonnet-latest`)
5. Click en **Guardar**

⚠ **Tu API key NUNCA sale de tu dispositivo.** Solo se envía al
servidor del proveedor que configures (OpenAI/Anthropic).

---

## 🧠 ¿Cómo funciona la "IA"?

Esta app es **una réplica funcional**, no una IA neuronal real:

- **Modo offline:** usa pattern matching y plantillas pre-cargadas
- **Modo online (con API):** delega a OpenAI/Anthropic para respuestas reales
- **Tamaño:** ~80 KB (HTML+CSS+JS) — una IA real (modelo neuronal) requeriría 1-100 GB y GPUs

Para una IA verdaderamente local de tamaño grande necesitarías un modelo
como Llama, Mistral, etc. ejecutado con `llama.cpp` o `ollama`. Eso está
fuera del alcance de esta app pero puedes integrarlo modificando `app.js`
para apuntar a tu servidor local de Ollama (`http://localhost:11434`).

---

## 🔧 Personalización

### Añadir nuevas plantillas

Edita `knowledge_base.js` y agrega:

```javascript
SCRIPT_TEMPLATES.mi_nuevo_script = {
    title: "Mi Script",
    desc: "Descripción corta",
    code: `-- tu código Lua aquí
print("Hola FE")`
};
```

### Cambiar tema visual

Edita `style.css`. Los colores principales son:
- Naranja nuclear: `#ff7800`
- Verde: `#00ff64`
- Negro: `#000`

### Cambiar el avatar/logo

Reemplaza el `☢` en `index.html` (línea del `class="logo"` y `class="msg-avatar"`).

---

## 📋 Requisitos técnicos

| Plataforma | Requisito |
|------------|-----------|
| Navegador | Chrome 90+, Firefox 88+, Safari 14+, Edge 90+ |
| Python | 3.8+ (solo si usas launcher) |
| .exe | PyInstaller (incluido en build_exe.bat) |
| APK | Buildozer + Java JDK 17 + Android SDK |

---

## 🎨 Capturas

```
╔══════════════════════════════════════════════════════════╗
║  ☢  FeDestruction IA              [● SCRIPT ]            ║
║  Asistente de Scripts Roblox FE | v1.0                  ║
╠══════════════════════════════════════════════════════════╣
║  [⚡ Script]  [💬 Original]  [⚙ API]                     ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║   ☢ FeDestruction IA                                    ║
║   ┌────────────────────────────────────────┐             ║
║   │ ¡Hola! Soy FeDestruction IA, tu        │             ║
║   │ asistente para scripts FE de Roblox.   │             ║
║   │ Puedo ayudarte con: ...                │             ║
║   └────────────────────────────────────────┘             ║
║                                                          ║
║                     ┌──────────────────────┐  TÚ         ║
║                     │ plantilla nuke       │             ║
║                     └──────────────────────┘             ║
║                                                          ║
║   ☢ ┌──────────────────────────────────────┐            ║
║     │ 📜 Nuke FE (Explosión Nuclear)        │            ║
║     │ Crea una explosión masiva...          │            ║
║     │ [código Lua aquí]                     │            ║
║     └──────────────────────────────────────┘            ║
╠══════════════════════════════════════════════════════════╣
║  [Escribe aquí tu pregunta...] [▶]                       ║
╚══════════════════════════════════════════════════════════╝
```

---

## ⚠ Aviso

Este proyecto está hecho con fines **educativos y de investigación de
seguridad**. El uso de exploits en juegos viola los Términos de Servicio
de Roblox y puede resultar en baneo permanente de tu cuenta. **Úsalo
bajo tu propia responsabilidad.**

---

**Versión:** 1.0 OfEnd Edition
**Fecha:** 22 de Abril, 2026
**Compatible con:** Roblox v2.717.985
