@echo off
REM ╔════════════════════════════════════════════════════════════╗
REM ║   FeDestruction IA - Build .EXE para Windows               ║
REM ║   Requiere: Python 3.8+ y PyInstaller                      ║
REM ╚════════════════════════════════════════════════════════════╝

echo ════════════════════════════════════════════════
echo  FeDestruction IA - Build .EXE para Windows
echo ════════════════════════════════════════════════
echo.

REM Verificar Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python no instalado. Descarga desde python.org
    pause
    exit /b 1
)

REM Instalar PyInstaller si no está
echo [1/3] Verificando PyInstaller...
pip show pyinstaller >nul 2>&1
if errorlevel 1 (
    echo       Instalando PyInstaller...
    pip install pyinstaller
)

REM Build
echo [2/3] Compilando .exe...
pyinstaller ^
    --onefile ^
    --windowed ^
    --name "FeDestructionIA" ^
    --icon=NONE ^
    --add-data "index.html;." ^
    --add-data "style.css;." ^
    --add-data "app.js;." ^
    --add-data "knowledge_base.js;." ^
    launcher.py

if errorlevel 1 (
    echo [ERROR] Compilación fallida
    pause
    exit /b 1
)

echo [3/3] Limpieza...
rmdir /s /q build
del FeDestructionIA.spec

echo.
echo ════════════════════════════════════════════════
echo  ✓ COMPLETADO
echo  El .exe está en: dist\FeDestructionIA.exe
echo ════════════════════════════════════════════════
pause
