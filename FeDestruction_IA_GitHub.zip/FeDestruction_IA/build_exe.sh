#!/bin/bash
# ╔════════════════════════════════════════════════════════════╗
# ║   FeDestruction IA - Build binario para Linux/Mac          ║
# ║   Requiere: Python 3.8+ y PyInstaller                      ║
# ╚════════════════════════════════════════════════════════════╝

set -e

echo "════════════════════════════════════════════════"
echo " FeDestruction IA - Build para Linux/Mac"
echo "════════════════════════════════════════════════"
echo

# Verificar Python
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python3 no instalado"
    exit 1
fi

# Instalar PyInstaller
echo "[1/3] Verificando PyInstaller..."
if ! python3 -c "import PyInstaller" &> /dev/null; then
    echo "      Instalando PyInstaller..."
    pip3 install pyinstaller
fi

# Build
echo "[2/3] Compilando binario..."
pyinstaller \
    --onefile \
    --name "FeDestructionIA" \
    --add-data "index.html:." \
    --add-data "style.css:." \
    --add-data "app.js:." \
    --add-data "knowledge_base.js:." \
    launcher.py

# Limpieza
echo "[3/3] Limpieza..."
rm -rf build
rm -f FeDestructionIA.spec

echo
echo "════════════════════════════════════════════════"
echo " ✓ COMPLETADO"
echo " El binario está en: dist/FeDestructionIA"
echo " Para ejecutarlo: ./dist/FeDestructionIA"
echo "════════════════════════════════════════════════"
