#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# Constructor automático del APK FeDestruction IA
# Uso: bash build_apk.sh
# ═══════════════════════════════════════════════════════════════

set -e

echo "☢ FeDestruction IA - Constructor APK"
echo "════════════════════════════════════"
echo ""

# 1. Verificar que estamos en el directorio correcto
if [ ! -f "buildozer.spec" ]; then
    echo "❌ Error: ejecuta este script desde FeDestruction_IA/android/"
    exit 1
fi

# 2. Verificar dependencias
echo "▶ Verificando dependencias..."
MISSING=""
command -v python3       >/dev/null 2>&1 || MISSING="$MISSING python3"
command -v java          >/dev/null 2>&1 || MISSING="$MISSING openjdk-17-jdk"
command -v buildozer     >/dev/null 2>&1 || MISSING="$MISSING buildozer(pip)"

if [ -n "$MISSING" ]; then
    echo "❌ Faltan dependencias:$MISSING"
    echo ""
    echo "Instalación rápida (Ubuntu/Debian):"
    echo "  sudo apt update"
    echo "  sudo apt install -y python3-pip openjdk-17-jdk autoconf libtool pkg-config zlib1g-dev libncurses-dev cmake libffi-dev libssl-dev"
    echo "  pip3 install --user buildozer cython==0.29.36"
    exit 1
fi
echo "  ✅ Todas las dependencias presentes"

# 3. Copiar archivos web del directorio padre
echo ""
echo "▶ Copiando archivos web..."
for f in index.html style.css app.js knowledge_base.js; do
    if [ -f "../$f" ]; then
        cp "../$f" .
        echo "  ✅ $f"
    else
        echo "  ❌ ../$f no encontrado"
        exit 1
    fi
done

# 4. Limpiar build anterior si existe
if [ -d ".buildozer" ]; then
    read -p "▶ ¿Limpiar build anterior? (más lento pero más confiable) [s/N] " resp
    if [ "$resp" = "s" ] || [ "$resp" = "S" ]; then
        echo "  🗑 Limpiando..."
        buildozer android clean
    fi
fi

# 5. Compilar
echo ""
echo "▶ Compilando APK (esto puede tardar 30-60 min la PRIMERA vez)..."
echo "  (Buildozer descargará Android SDK, NDK, etc. si es la primera vez)"
echo ""
buildozer android debug

# 6. Resultado
echo ""
echo "════════════════════════════════════"
if [ -d "bin" ] && ls bin/*.apk >/dev/null 2>&1; then
    APK=$(ls -t bin/*.apk | head -1)
    SIZE=$(du -h "$APK" | cut -f1)
    echo "✅ APK construido con éxito"
    echo "   Archivo: $APK"
    echo "   Tamaño:  $SIZE"
    echo ""
    echo "▶ Para instalar en tu Android:"
    echo "   1. Conecta el teléfono por USB con depuración USB activa"
    echo "   2. adb install -r $APK"
    echo "   O pasa el archivo manualmente y abrelo en el teléfono."
else
    echo "❌ La compilación terminó pero no se encontró APK en bin/"
    echo "   Revisa los logs arriba para ver qué pasó."
    exit 1
fi
