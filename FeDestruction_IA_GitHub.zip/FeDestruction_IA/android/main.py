"""
FeDestruction IA - Versión Android (Kivy + WebView)
Carga el index.html en un WebView nativo de Android.

Para construir el APK:
    cd FeDestruction_IA/android
    cp ../index.html ../style.css ../app.js ../knowledge_base.js .
    buildozer android debug

El APK resultante estará en: bin/fedestructionia-1.0-debug.apk
"""

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.utils import platform
import os


class FeDestructionApp(App):
    """App principal - en Android carga WebView, en PC muestra mensaje."""

    title = "FeDestruction IA"

    def build(self):
        layout = BoxLayout(orientation='vertical')

        if platform == 'android':
            return self.build_android(layout)
        else:
            return self.build_desktop(layout)

    def build_android(self, layout):
        """En Android: WebView que carga index.html localmente."""
        try:
            from jnius import autoclass
            from android.runnable import run_on_ui_thread

            WebView          = autoclass('android.webkit.WebView')
            WebViewClient    = autoclass('android.webkit.WebViewClient')
            WebSettings      = autoclass('android.webkit.WebSettings')
            PythonActivity   = autoclass('org.kivy.android.PythonActivity')

            activity = PythonActivity.mActivity

            @run_on_ui_thread
            def create_webview(_dt=None):
                webview = WebView(activity)
                webview.setWebViewClient(WebViewClient())

                settings = webview.getSettings()
                # ── JavaScript y almacenamiento DOM (necesario para WebLLM/IndexedDB) ──
                settings.setJavaScriptEnabled(True)
                settings.setDomStorageEnabled(True)
                settings.setDatabaseEnabled(True)

                # ── Acceso a archivos locales (HTML, CSS, JS bundled en el APK) ──
                settings.setAllowFileAccess(True)
                settings.setAllowFileAccessFromFileURLs(True)
                settings.setAllowUniversalAccessFromFileURLs(True)
                settings.setAllowContentAccess(True)

                # ── CACHÉ AGRESIVO: el modelo IA descargado queda guardado dentro del APK ──
                # LOAD_DEFAULT = usa caché siempre que esté disponible (offline = usa caché)
                settings.setCacheMode(WebSettings.LOAD_DEFAULT)
                settings.setMediaPlaybackRequiresUserGesture(False)

                # ── Habilitar WebGPU experimental (necesario para WebLLM) ──
                # En Android 14+ con Chrome WebView 121+, WebGPU está disponible pero hay que activarlo
                try:
                    settings.setOffscreenPreRaster(True)
                except Exception:
                    pass

                # ── Cargar archivo HTML local (bundled en assets del APK) ──
                html_path = os.path.join(os.path.dirname(__file__), 'index.html')
                webview.loadUrl(f"file://{html_path}")

                activity.setContentView(webview)

            create_webview()
            return Label(text="Iniciando WebView...")

        except Exception as e:
            return Label(text=f"Error iniciando WebView: {e}")

    def build_desktop(self, layout):
        """En PC: mostrar mensaje de info."""
        title = Label(
            text="[size=24][color=ff7800]FeDestruction IA[/color][/size]",
            markup=True,
            size_hint_y=None,
            height=80,
        )
        info = Label(
            text=(
                "[color=00ff64]Esta es la versión Android.[/color]\n\n"
                "Para PC, ejecuta el launcher principal:\n"
                "[i]python launcher.py[/i]\n\n"
                "O abre [b]index.html[/b] en tu navegador."
            ),
            markup=True,
            halign='center',
        )
        layout.add_widget(title)
        layout.add_widget(info)
        return layout


if __name__ == "__main__":
    FeDestructionApp().run()
