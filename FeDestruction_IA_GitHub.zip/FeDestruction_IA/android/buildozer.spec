[app]

# (str) Title of your application
title = FeDestruction IA

# (str) Package name
package.name = fedestructionia

# (str) Package domain (needed for android/ios packaging)
package.domain = com.fedestruction.ia

# (str) Source code where the main.py live
source.dir = .

# (list) Source files to include
source.include_exts = py,png,jpg,kv,atlas,html,css,js,json

# (list) Source files to exclude
source.exclude_exts = spec

# (str) Application versioning
version = 1.0

# (list) Application requirements
requirements = python3,kivy==2.3.0,kivymd

# (str) Supported orientation: landscape, portrait, all, sensor
orientation = portrait

# (bool) Indicate if the application should be fullscreen or not
fullscreen = 0

# (list) Permissions
# INTERNET: solo necesario la PRIMERA vez para descargar el modelo IA
# ACCESS_NETWORK_STATE: para detectar si hay conexión al pre-descargar
# WRITE_EXTERNAL_STORAGE: para guardar/exportar la librería de scripts
android.permissions = INTERNET,ACCESS_NETWORK_STATE,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE

# (int) Target Android API
android.api = 33

# (int) Minimum API your APK / AAB will support
android.minapi = 21

# (str) Android NDK version to use
android.ndk = 25b

# (bool) Use --private data storage (True) or --dir public storage (False)
android.private_storage = True

# (str) Android entry point, default is ok for Kivy-based app
android.entrypoint = org.kivy.android.PythonActivity

# (list) Java .jar files to add to the libs
# android.add_jars = lib/*.jar

# (str) Android logcat filters to use
android.logcat_filters = *:S python:D

# (str) Android additional adb arguments
# android.adb_args = -H host.docker.internal

# (bool) Copy library instead of making a libpymodules.so
android.copy_libs = 1

# (str) The Android arch to build for, choices: armeabi-v7a, arm64-v8a, x86, x86_64
android.archs = arm64-v8a, armeabi-v7a

# (bool) enables Android auto backup feature (Android API >=23)
android.allow_backup = True


[buildozer]

# (int) Log level (0 = error only, 1 = info, 2 = debug (with command output))
log_level = 2

# (int) Display warning if buildozer is run as root (0 = False, 1 = True)
warn_on_root = 1
