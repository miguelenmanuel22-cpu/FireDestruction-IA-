// ═══════════════════════════════════════════════════════════════
// FeDestruction IA - Base de Conocimiento
// Plantillas de scripts Roblox FE + Conocimiento general
// ═══════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════
// Base de datos de vulnerabilidades comunes en juegos Roblox
// ═══════════════════════════════════════════════════════════════
const VULN_DATABASE = {
  remotes: {
    name: "RemoteEvent/Function sin validación servidor",
    severity: "CRÍTICA",
    desc: "El bug más común de FE. El servidor confía en lo que el cliente envía vía RemoteEvent o RemoteFunction sin validar.",
    exploit: `-- Cliente exploit:
local rs = game:GetService("ReplicatedStorage")
local remote = rs:FindFirstChild("GiveCash") or rs:FindFirstChild("BuyItem")

-- Dispara con valores absurdos
remote:FireServer(999999999)              -- Da dinero infinito
remote:FireServer("Sword", -1)            -- Compra item con precio negativo
remote:InvokeServer("admin_panel_open")   -- Activa funciones de admin

-- Scanner automático:
for _, r in ipairs(rs:GetDescendants()) do
    if r:IsA("RemoteEvent") then
        pcall(function() r:FireServer(math.huge) end)
    end
end`,
    mitigation: `-- Server-side (ServerScript):
remote.OnServerEvent:Connect(function(player, amount)
    -- VALIDAR TIPO
    if typeof(amount) ~= "number" then return end
    -- VALIDAR RANGO
    if amount <= 0 or amount > 100 then return end
    -- VALIDAR RATE LIMIT
    if not canFire(player) then return end
    -- VALIDAR LÓGICA DE NEGOCIO
    if player.leaderstats.Cash.Value < amount then return end

    player.leaderstats.Cash.Value = player.leaderstats.Cash.Value - amount
end)`
  },

  datastore: {
    name: "DataStore key injection / overwrite",
    severity: "ALTA",
    desc: "Si el nombre de la key del DataStore se construye con input del cliente, se puede sobreescribir o leer datos de otros jugadores.",
    exploit: `-- Si el server hace algo como:
-- ds:SetAsync("save_" .. player.Name, data)
-- Un exploiter cambia su display name (vía hook) y sobreescribe otro save.

-- O si el server toma input del cliente para la key:
remote:FireServer("save_admin_" .. game.PlaceId)`,
    mitigation: `-- Usa SIEMPRE UserId, NUNCA Name:
local ds = DataStoreService:GetDataStore("PlayerSaves_v2")
ds:SetAsync("user_" .. player.UserId, data)

-- Wrap con pcall + UpdateAsync para evitar race conditions:
ds:UpdateAsync("user_" .. player.UserId, function(old)
    return mergeData(old, data)
end)`
  },

  walkspeed: {
    name: "WalkSpeed/JumpPower spoofing",
    severity: "MEDIA",
    desc: "El cliente puede modificar su Humanoid.WalkSpeed/JumpPower y el servidor lo replica si no hay sanity checks.",
    exploit: `-- Speedhack básico:
local plr = game.Players.LocalPlayer
plr.Character.Humanoid.WalkSpeed = 500
plr.Character.Humanoid.JumpPower = 200

-- Persistente (mantiene aunque el server lo resetee):
game:GetService("RunService").Heartbeat:Connect(function()
    local h = plr.Character and plr.Character:FindFirstChildOfClass("Humanoid")
    if h then h.WalkSpeed = 500 end
end)`,
    mitigation: `-- Server: monitor de velocidad real
local last = {}
game:GetService("RunService").Heartbeat:Connect(function(dt)
    for _, plr in ipairs(game.Players:GetPlayers()) do
        local hrp = plr.Character and plr.Character:FindFirstChild("HumanoidRootPart")
        if hrp then
            local lastPos = last[plr]
            if lastPos then
                local dist = (hrp.Position - lastPos).Magnitude
                if dist / dt > 30 then  -- ~30 studs/sec máximo
                    plr:Kick("Speed exploit detectado")
                end
            end
            last[plr] = hrp.Position
        end
    end
end)`
  },

  clientadmin: {
    name: "Lista de admins en LocalScript",
    severity: "CRÍTICA",
    desc: "Verificar permisos de admin SOLO en cliente es trivial de bypassear con un decompiler.",
    exploit: `-- Script.lua decompilado:
local ADMINS = {12345, 67890, 11111}
if table.find(ADMINS, plr.UserId) then
    showAdminPanel()
end

-- Exploit: hookea la función o cambia tu UserId returned
hookmetamethod(game, "__index", function(t, k)
    if k == "UserId" and t == game.Players.LocalPlayer then return 12345 end
    return rawget(t, k)
end)`,
    mitigation: `-- TODA verificación de admin debe ser server-side:
local ADMINS = {12345, 67890}  -- En ServerScript, no LocalScript

remote.OnServerEvent:Connect(function(player, action)
    if not table.find(ADMINS, player.UserId) then
        warn(player.Name .. " intentó usar admin sin permisos")
        return
    end
    -- Ejecutar acción
end)`
  },

  executors: {
    name: "Detección/bypass de executors",
    severity: "ALTA",
    desc: "Los anti-cheats client-side detectan executors. Patrones comunes y cómo bypassearlos.",
    exploit: `-- Detector típico que el juego usa:
if getgenv or getrenv or hookfunction or syn or KRNL_LOADED then
    plr:Kick("Exploiter")
end

-- Bypass: hook anti-detect ANTES de que cargue el detector
local mt = getrawmetatable(game)
setreadonly(mt, false)
local oldIndex = mt.__index
mt.__index = function(t, k)
    if k == "Kick" then return function() end end  -- Anula Kick
    return oldIndex(t, k)
end
setreadonly(mt, true)

-- O wipe globals comunes:
getgenv().getgenv = nil`,
    mitigation: `-- Detector server-side (no bypasseable desde cliente):
-- 1. Patrones de movimiento imposible (teleport, fly)
-- 2. Latencia entre input y acción
-- 3. Honeypot RemoteEvents (si el cliente los llama, es exploiter)
local honeypot = Instance.new("RemoteEvent", ReplicatedStorage)
honeypot.Name = "DebugInternal_" .. math.random(1e9)
honeypot.OnServerEvent:Connect(function(plr)
    plr:Kick("Honeypot triggered")
end)`
  },

  chatfilter: {
    name: "Bypass de chat filter",
    severity: "MEDIA",
    desc: "Si el chat custom no usa TextService:FilterStringAsync, los mensajes son texto crudo y se pueden inyectar HTML/markup en TextLabel.RichText.",
    exploit: `-- Si el server hace:
chatRemote.OnServerEvent:Connect(function(plr, msg)
    chatLabel.Text = plr.Name .. ": " .. msg
end)

-- Cliente envía:
chatRemote:FireServer('<font color="rgb(255,0,0)" size="60">HACKED</font>')
-- Si chatLabel.RichText = true, se renderiza como HTML.`,
    mitigation: `-- USA TextService:
local TextService = game:GetService("TextService")
chatRemote.OnServerEvent:Connect(function(plr, msg)
    local ok, filtered = pcall(function()
        return TextService:FilterStringAsync(msg, plr.UserId)
    end)
    if not ok then return end
    local clean = filtered:GetNonChatStringForBroadcastAsync()
    chatLabel.Text = plr.Name .. ": " .. clean
end)`
  },

  hopperbin: {
    name: "HopperBin / herramientas legacy",
    severity: "BAJA",
    desc: "HopperBin está deprecada desde 2015 pero algunos juegos viejos aún la usan. Tools sin validación de cooldown permiten spam.",
    exploit: `-- Tool sin cooldown:
tool.Activated:Connect(function()
    fireSwordRemote:FireServer()  -- Spam infinito
end)

-- Loop:
while task.wait() do
    fireSwordRemote:FireServer()  -- 60 hits/seg
end`,
    mitigation: `-- Server con cooldown:
local cooldowns = {}
fireSwordRemote.OnServerEvent:Connect(function(plr)
    local last = cooldowns[plr] or 0
    if tick() - last < 0.5 then return end  -- Mínimo 500ms entre hits
    cooldowns[plr] = tick()
    -- Lógica del swing
end)`
  },
};

const SCRIPT_TEMPLATES = {

  loader: {
    title: "Loader Modular FE",
    desc: "Carga módulos desde GitHub con reintentos y detección de executor.",
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/USERNAME/REPO/main/Fire_destruction_Hub_Beta_Of_End/FE_DESTRUCTION_HUB_Loader.lua"))()

-- O loader personalizado:
local GITHUB = "https://raw.githubusercontent.com/TU_USER/TU_REPO/main/"

local function loadModule(name)
    local ok, code = pcall(function()
        return game:HttpGet(GITHUB .. name .. ".lua", true)
    end)
    if not ok then warn("Error: " .. name); return end

    local chunk = loadstring(code, "=" .. name)
    if chunk then chunk() end
end

loadModule("MainScript")
loadModule("GUI")
loadModule("Exploits")`
  },

  fly: {
    title: "Fly FE (Vuelo) - APIs modernas 2026",
    desc: "Vuelo con LinearVelocity + AlignOrientation (reemplaza BodyVelocity/BodyGyro).",
    code: `local Players = game:GetService("Players")
local UIS = game:GetService("UserInputService")
local RS = game:GetService("RunService")
local plr = Players.LocalPlayer
local char = plr.Character or plr.CharacterAdded:Wait()
local hrp = char:WaitForChild("HumanoidRootPart")

local FLYING = false
local SPEED = 80
local att, lv, ao

local function startFly()
    att = Instance.new("Attachment")
    att.Parent = hrp

    lv = Instance.new("LinearVelocity")
    lv.Attachment0 = att
    lv.RelativeTo = Enum.ActuatorRelativeTo.World
    lv.MaxForce = math.huge
    lv.VectorVelocity = Vector3.zero
    lv.Parent = hrp

    ao = Instance.new("AlignOrientation")
    ao.Attachment0 = att
    ao.Mode = Enum.OrientationAlignmentMode.OneAttachment
    ao.MaxTorque = math.huge
    ao.Responsiveness = 200
    ao.Parent = hrp

    FLYING = true

    RS.RenderStepped:Connect(function()
        if not FLYING or not lv then return end
        local cam = workspace.CurrentCamera
        local move = Vector3.zero
        if UIS:IsKeyDown(Enum.KeyCode.W) then move = move + cam.CFrame.LookVector end
        if UIS:IsKeyDown(Enum.KeyCode.S) then move = move - cam.CFrame.LookVector end
        if UIS:IsKeyDown(Enum.KeyCode.A) then move = move - cam.CFrame.RightVector end
        if UIS:IsKeyDown(Enum.KeyCode.D) then move = move + cam.CFrame.RightVector end
        if UIS:IsKeyDown(Enum.KeyCode.Space) then move = move + Vector3.new(0,1,0) end
        if UIS:IsKeyDown(Enum.KeyCode.LeftControl) then move = move - Vector3.new(0,1,0) end

        lv.VectorVelocity = move.Magnitude > 0 and move.Unit * SPEED or Vector3.zero
        ao.CFrame = CFrame.lookAt(Vector3.zero, move.Magnitude > 0 and move or cam.CFrame.LookVector)
    end)
end

local function stopFly()
    FLYING = false
    if lv then lv:Destroy() end
    if ao then ao:Destroy() end
    if att then att:Destroy() end
end

UIS.InputBegan:Connect(function(i, gp)
    if gp then return end
    if i.KeyCode == Enum.KeyCode.F then
        if FLYING then stopFly() else startFly() end
    end
end)

print("[FLY v6] LinearVelocity + AlignOrientation | Presiona F")`
  },

  noclip: {
    title: "Noclip FE (Atravesar paredes)",
    desc: "Desactiva CanCollide en todas las partes del personaje.",
    code: `local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UIS = game:GetService("UserInputService")
local plr = Players.LocalPlayer

local NOCLIP = false
local conn

local function toggle()
    NOCLIP = not NOCLIP
    if NOCLIP then
        conn = RunService.Stepped:Connect(function()
            if plr.Character then
                for _, p in ipairs(plr.Character:GetDescendants()) do
                    if p:IsA("BasePart") then p.CanCollide = false end
                end
            end
        end)
        print("[NOCLIP] ACTIVADO")
    else
        if conn then conn:Disconnect() end
        print("[NOCLIP] DESACTIVADO")
    end
end

UIS.InputBegan:Connect(function(i, gp)
    if not gp and i.KeyCode == Enum.KeyCode.N then toggle() end
end)

print("[NOCLIP] Presiona N")`
  },

  nuke: {
    title: "Nuke FE (Explosión Nuclear)",
    desc: "Crea una explosión masiva con efectos visuales y sonido.",
    code: `local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")
local Lighting = game:GetService("Lighting")
local Debris = game:GetService("Debris")
local plr = Players.LocalPlayer

local function nuke()
    local char = plr.Character
    if not char then return end
    local hrp = char:FindFirstChild("HumanoidRootPart")
    if not hrp then return end

    local pos = hrp.Position

    -- Flash blanco
    local cc = Instance.new("ColorCorrectionEffect")
    cc.Brightness = 1
    cc.Contrast = 2
    cc.Parent = Lighting
    Debris:AddItem(cc, 3)

    -- Explosión inicial
    local exp = Instance.new("Explosion")
    exp.Position = pos
    exp.BlastRadius = 200
    exp.BlastPressure = 5000000
    exp.Parent = Workspace

    -- Hongo nuclear
    task.spawn(function()
        for i = 1, 30 do
            local p = Instance.new("Part")
            p.Shape = Enum.PartType.Ball
            p.Size = Vector3.new(40, 40, 40) * (1 + i * 0.1)
            p.Position = pos + Vector3.new(0, i * 8, 0)
            p.BrickColor = BrickColor.new("Bright orange")
            p.Material = Enum.Material.Neon
            p.Anchored = true
            p.CanCollide = false
            p.Transparency = 0.3
            p.Parent = Workspace
            Debris:AddItem(p, 5)
            task.wait(0.05)
        end
    end)

    -- Onda expansiva
    for i = 1, 5 do
        task.spawn(function()
            local ring = Instance.new("Part")
            ring.Shape = Enum.PartType.Cylinder
            ring.Size = Vector3.new(2, 400, 400)
            ring.CFrame = CFrame.new(pos) * CFrame.Angles(0, 0, math.rad(90))
            ring.BrickColor = BrickColor.new("Bright orange")
            ring.Material = Enum.Material.Neon
            ring.Anchored = true
            ring.CanCollide = false
            ring.Transparency = 0.5
            ring.Parent = Workspace

            for t = 0, 1, 0.05 do
                ring.Size = Vector3.new(2, 400 + t * 800, 400 + t * 800)
                ring.Transparency = 0.5 + t * 0.5
                task.wait(0.03)
            end
            ring:Destroy()
        end)
        task.wait(0.2)
    end

    print("[NUKE] ☢ EXPLOSIÓN NUCLEAR DETONADA")
end

nuke()`
  },

  remotescanner: {
    title: "Remote Scanner FE",
    desc: "Escanea todos los RemoteEvents/Functions del juego.",
    code: `local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local found = {}

local function scan(parent, path)
    for _, obj in ipairs(parent:GetChildren()) do
        if obj:IsA("RemoteEvent") or obj:IsA("RemoteFunction") then
            table.insert(found, {
                name = obj.Name,
                class = obj.ClassName,
                path = obj:GetFullName()
            })
        end
        scan(obj, path .. "/" .. obj.Name)
    end
end

scan(ReplicatedStorage, "ReplicatedStorage")
scan(Workspace, "Workspace")

print("════ REMOTES ENCONTRADOS: " .. #found .. " ════")
for _, r in ipairs(found) do
    print(string.format("  [%s] %s → %s", r.class, r.name, r.path))
end

-- Probar fuego: descomentar para disparar TODOS (cuidado)
-- for _, r in ipairs(found) do
--     if r.class == "RemoteEvent" then
--         pcall(function() game:GetService(...):FireServer() end)
--     end
-- end`
  },

  guicircular: {
    title: "GUI Circular Draggable",
    desc: "Botón flotante circular arrastrable con animación.",
    code: `local Players = game:GetService("Players")
local UIS = game:GetService("UserInputService")
local plr = Players.LocalPlayer

local sg = Instance.new("ScreenGui")
sg.Name = "FE_GUI"
sg.ResetOnSpawn = false
sg.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
sg.Parent = plr:WaitForChild("PlayerGui")

local btn = Instance.new("TextButton")
btn.Size = UDim2.new(0, 70, 0, 70)
btn.Position = UDim2.new(0, 30, 0.5, 0)
btn.BackgroundColor3 = Color3.fromRGB(255, 120, 0)
btn.Text = "☢"
btn.TextScaled = true
btn.TextColor3 = Color3.fromRGB(0, 0, 0)
btn.Font = Enum.Font.GothamBold
btn.BorderSizePixel = 0
btn.Parent = sg

local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(1, 0)
corner.Parent = btn

local stroke = Instance.new("UIStroke")
stroke.Color = Color3.fromRGB(0, 255, 100)
stroke.Thickness = 3
stroke.Parent = btn

-- Drag
local dragging, dragStart, startPos
btn.InputBegan:Connect(function(i)
    if i.UserInputType == Enum.UserInputType.MouseButton1 or i.UserInputType == Enum.UserInputType.Touch then
        dragging = true
        dragStart = i.Position
        startPos = btn.Position
    end
end)
btn.InputEnded:Connect(function(i)
    if i.UserInputType == Enum.UserInputType.MouseButton1 or i.UserInputType == Enum.UserInputType.Touch then
        dragging = false
    end
end)
UIS.InputChanged:Connect(function(i)
    if dragging then
        local d = i.Position - dragStart
        btn.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + d.X,
                                  startPos.Y.Scale, startPos.Y.Offset + d.Y)
    end
end)

btn.MouseButton1Click:Connect(function()
    print("☢ MENU FE")
    -- Tu código del menú aquí
end)`
  },

  antibyfron: {
    title: "Anti-Byfron Heartbeat",
    desc: "Patrón de evasión con jitter aleatorio y decoys.",
    code: `local RunService = game:GetService("RunService")
local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")

local patterns = {
    function() pcall(function() return Players:GetPlayers() end) end,
    function() pcall(function() return Workspace.CurrentCamera end) end,
    function() pcall(function() return game.PlaceId end) end,
    function() pcall(function() return Workspace.Gravity end) end,
    function() pcall(function() return Players.LocalPlayer.UserId end) end,
}

local function shuffle(t)
    for i = #t, 2, -1 do
        local j = math.random(1, i)
        t[i], t[j] = t[j], t[i]
    end
end

task.spawn(function()
    while true do
        local jitter = math.random() * 3 + 0.5  -- 0.5-3.5s
        task.wait(jitter)

        local copy = table.clone(patterns)
        shuffle(copy)
        for _, fn in ipairs(copy) do pcall(fn) end
    end
end)

print("[ANTIBYFRON] Heartbeat con jitter + decoys ACTIVO")`
  },

  cloak_thread: {
    title: "Thread Cloaking",
    desc: "Envuelve una función en capas de coroutines para ocultarla.",
    code: `-- Envuelve la función en N capas de coroutines
local function cloak(fn, layers)
    layers = layers or 3
    local wrapped = fn
    for i = 1, layers do
        local prev = wrapped
        wrapped = function(...)
            local args = {...}
            local co = coroutine.create(function() prev(table.unpack(args)) end)
            pcall(coroutine.resume, co)
        end
    end
    return wrapped
end

-- Uso
local miFuncion = cloak(function()
    print("Función oculta ejecutándose")
    -- Tu código exploit aquí
end, 3)

task.spawn(miFuncion)`
  },

  killaura: {
    title: "Kill Aura FE",
    desc: "Ataca automáticamente jugadores cercanos (requiere remote válido).",
    code: `local Players = game:GetService("Players")
local RS = game:GetService("ReplicatedStorage")
local plr = Players.LocalPlayer

local RADIUS = 30
local ACTIVE = true

-- Buscar el remote de daño (ajustar al juego)
local damageRemote = RS:FindFirstChild("DamageEvent") or RS:FindFirstChild("HitEvent")

task.spawn(function()
    while ACTIVE do
        task.wait(0.1)
        local char = plr.Character
        if not char then continue end
        local hrp = char:FindFirstChild("HumanoidRootPart")
        if not hrp then continue end

        for _, target in ipairs(Players:GetPlayers()) do
            if target ~= plr and target.Character then
                local thrp = target.Character:FindFirstChild("HumanoidRootPart")
                if thrp and (thrp.Position - hrp.Position).Magnitude <= RADIUS then
                    if damageRemote then
                        pcall(function() damageRemote:FireServer(target.Character) end)
                    end
                end
            end
        end
    end
end)

print("[KILLAURA] Activo - radio: " .. RADIUS)`
  },

  speed: {
    title: "Speed Boost FE",
    desc: "Aumenta la velocidad del personaje.",
    code: `local Players = game:GetService("Players")
local plr = Players.LocalPlayer

local SPEED = 100  -- velocidad normal: 16

local function applySpeed()
    local char = plr.Character or plr.CharacterAdded:Wait()
    local hum = char:WaitForChild("Humanoid")
    hum.WalkSpeed = SPEED
    print("[SPEED] WalkSpeed = " .. SPEED)
end

applySpeed()
plr.CharacterAdded:Connect(applySpeed)`
  },

  godmode: {
    title: "God Mode FE",
    desc: "Modo dios: HP infinito y reset al recibir daño.",
    code: `local Players = game:GetService("Players")
local plr = Players.LocalPlayer

local function applyGod()
    local char = plr.Character or plr.CharacterAdded:Wait()
    local hum = char:WaitForChild("Humanoid")

    hum.MaxHealth = math.huge
    hum.Health = math.huge

    hum.HealthChanged:Connect(function(h)
        if h < hum.MaxHealth then
            hum.Health = math.huge
        end
    end)

    print("[GODMODE] HP infinito")
end

applyGod()
plr.CharacterAdded:Connect(applyGod)`
  },

  teleport: {
    title: "Teleport to Click",
    desc: "Click en cualquier lado para teletransportarte allí.",
    code: `local Players = game:GetService("Players")
local UIS = game:GetService("UserInputService")
local Mouse = Players.LocalPlayer:GetMouse()

UIS.InputBegan:Connect(function(i, gp)
    if gp then return end
    if i.KeyCode == Enum.KeyCode.T then
        local char = Players.LocalPlayer.Character
        if char and char:FindFirstChild("HumanoidRootPart") and Mouse.Hit then
            char.HumanoidRootPart.CFrame = Mouse.Hit + Vector3.new(0, 3, 0)
            print("[TELEPORT] " .. tostring(Mouse.Hit.Position))
        end
    end
end)

print("[TELEPORT] Apunta y presiona T")`
  },
};

const COMMANDS = {
  ayuda:    "list_help",
  help:     "list_help",
  comandos: "list_help",
  lista:    "list_category",
  list:     "list_category",
  plantilla:"show_template",
  template: "show_template",
  crear:    "show_template",
  create:   "show_template",
  hola:     "greeting",
  hello:    "greeting",
  hi:       "greeting",
  gracias:  "thanks",
  thanks:   "thanks",
  quien:    "about",
  who:      "about",
  about:    "about",
};

const CATEGORIES = {
  exploits: ["nuke", "killaura", "remotescanner", "antibyfron"],
  funciones: ["fly", "noclip", "speed", "godmode", "teleport"],
  gui: ["guicircular"],
  executors: "Synapse X (10), KRNL (9), Solara (9), Wave (9), Script-Ware (10), Evon (8), Fluxus (8), Delta (7), Arceus X (8), Generic (6)",
};

const GREETINGS = [
  "¡Hola! ¿En qué te puedo ayudar con tu script Roblox FE? Escribe <code>ayuda</code> para ver opciones.",
  "¡Saludos exploiter! ☢ ¿Qué quieres construir hoy?",
  "¡Hola! Soy FeDestruction IA. Pídeme una plantilla o pregúntame algo.",
];

const ABOUT_TEXT = `
Soy <b>FeDestruction IA v1.0 (OfEnd Edition)</b>, una réplica local
optimizada para ayudarte con scripts FE de Roblox.
<br><br>
<b>Modo 1 (Script):</b> tengo plantillas pre-cargadas de scripts comunes
de exploit (fly, noclip, nuke, kill aura, etc.).
<br>
<b>Modo 2 (Original):</b> chat general usando el mismo sistema de
plantillas.
<br><br>
Para respuestas inteligentes verdaderas, conecta una API de OpenAI o
Anthropic en el botón <b>API</b>. Sin API key, uso solo conocimiento local.
<br><br>
<b>Funciono en:</b> PC (.exe), Android (apk), navegador web.
`;

const ORIGINAL_RESPONSES = {
  default: "No estoy seguro de eso, pero puedo ayudarte con scripts Roblox FE. Escribe <code>ayuda</code> para ver mis comandos.",
  como_funciona_fe: "FE (Filtering Enabled) es el sistema de seguridad de Roblox donde el cliente no puede modificar directamente al servidor. Para hackear FE necesitas usar RemoteEvents/RemoteFunctions vulnerables que el servidor expone.",
  que_es_byfron: "Byfron (ahora Hyperion) es el sistema anti-cheat de Roblox que detecta executors en el cliente. Usa heartbeats, detección de hooks, scanning de memoria y más. Mi módulo Anti-Byfron v6 implementa contramedidas.",
  mejor_executor: "Para 2026: Solara, Wave, Synapse X y Script-Ware son los más estables. KRNL tiene buen UNC. Fluxus y Evon son alternativas gratuitas decentes.",
};
