// ═══════════════════════════════════════════════════════════════
// FeDestruction IA - Lógica del chatbot
// ═══════════════════════════════════════════════════════════════

let currentMode = 'script';   // 'script' | 'vuln' | 'original'
let chatHistory = [];
let webllmEngine = null;      // Instancia de WebLLM (carga perezosa)
let webllmLoading = false;
let lastAIResponse = null;    // Última respuesta para guardar en librería

// ── Inicialización ────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
    spawnParticles(20);
    loadSettings();
    document.getElementById('userInput').focus();
});

// ── Partículas decorativas en el fondo ────────────────────────
function spawnParticles(count) {
    const container = document.getElementById('particles');
    for (let i = 0; i < count; i++) {
        const p = document.createElement('div');
        p.className = 'particle';
        p.style.left = Math.random() * 100 + '%';
        p.style.animationDuration = (8 + Math.random() * 12) + 's';
        p.style.animationDelay = (Math.random() * 10) + 's';
        const colors = ['#ff7800', '#00ff64', '#ffaa00'];
        const c = colors[Math.floor(Math.random() * colors.length)];
        p.style.background = c;
        p.style.boxShadow = `0 0 8px ${c}`;
        container.appendChild(p);
    }
}

// ── Cambio de modo ────────────────────────────────────────────
function switchMode(mode) {
    currentMode = mode;
    document.querySelectorAll('.mode-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.mode === mode);
    });

    const labels = { script: 'SCRIPT', vuln: 'VULN', original: 'CHAT' };
    const hints  = { script: 'Script', vuln: 'Vulnerabilidades', original: 'Chat' };
    document.getElementById('modeLabel').textContent = labels[mode] || mode.toUpperCase();
    document.getElementById('hintMode').textContent = hints[mode] || mode;

    const messages = {
        script:   "🔄 Modo <b>Script (Roblox FE)</b>. Pídeme plantillas: <code>plantilla nuke</code>, <code>plantilla fly</code>, etc.",
        vuln:     "🛡 Modo <b>Detección de Vulnerabilidades</b>. Comandos: <code>vuln remotes</code>, <code>vuln datastore</code>, <code>vuln executors</code>, <code>scan [código]</code>, o pega código Lua y lo analizo.",
        original: "💬 Modo <b>Chat general</b>. Pregúntame lo que quieras sobre Roblox, Lua, executors, etc.",
    };
    addBotMessage(messages[mode] || `🔄 Modo: ${mode}`);
}

// ── Manejo del input ──────────────────────────────────────────
function handleKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
}

async function sendMessage() {
    const input = document.getElementById('userInput');
    const text = input.value.trim();
    if (!text) return;

    addUserMessage(text);
    input.value = '';

    // Loading state
    const loadingId = addBotMessage('<i>Pensando...</i>');

    try {
        const response = await processMessage(text);
        updateMessage(loadingId, response);
    } catch (err) {
        updateMessage(loadingId, "⚠ Error: " + err.message);
    }
}

// ── Procesar mensaje ──────────────────────────────────────────
async function processMessage(text) {
    const settings = getSettings();

    // Si tiene API configurada, intenta usarla primero
    if (settings.provider !== 'none' && settings.apiKey) {
        try {
            return await callExternalAPI(text, settings);
        } catch (err) {
            console.warn('API falló, usando local:', err);
            return processLocally(text) +
                `<br><br><i>⚠ API falló (${err.message}). Respuesta local mostrada.</i>`;
        }
    }

    return processLocally(text);
}

// ── Procesamiento LOCAL (sin API) ─────────────────────────────
function processLocally(text) {
    const lower = text.toLowerCase().trim();
    const words = lower.split(/\s+/);
    const firstWord = words[0];

    // ── Saludos ──
    if (['hola', 'hello', 'hi', 'hey', 'buenas'].includes(firstWord)) {
        return GREETINGS[Math.floor(Math.random() * GREETINGS.length)];
    }

    // ── Acerca de ──
    if (lower.includes('quien eres') || lower.includes('que eres') || lower === 'about') {
        return ABOUT_TEXT;
    }

    // ── Gracias ──
    if (firstWord === 'gracias' || firstWord === 'thanks') {
        return "¡De nada! ☢ Sigue construyendo cosas geniales.";
    }

    // ── Ayuda ──
    if (firstWord === 'ayuda' || firstWord === 'help' || firstWord === 'comandos') {
        return buildHelp();
    }

    // ── Listas ──
    if (firstWord === 'lista' || firstWord === 'list') {
        const cat = words[1];
        return buildCategoryList(cat);
    }

    // ── Plantillas (plantilla X / crear X / template X / create X) ──
    if (['plantilla', 'template', 'crear', 'create'].includes(firstWord)) {
        const tplName = words.slice(1).join('');
        return showTemplate(tplName);
    }

    // ── Búsqueda directa por palabra clave ──
    for (const key in SCRIPT_TEMPLATES) {
        if (lower.includes(key)) {
            return showTemplate(key);
        }
    }

    // ── Modo Vulnerabilidades ──
    if (currentMode === 'vuln' || firstWord === 'vuln' || firstWord === 'scan') {
        // vuln [tipo]
        if (firstWord === 'vuln') {
            const v = words[1] || '';
            return showVulnerability(v);
        }
        // scan [código]
        if (firstWord === 'scan') {
            const code = text.substring(text.indexOf(' ') + 1);
            return scanLuaCode(code);
        }
        // Si está en modo vuln y manda código directo (detección por símbolos)
        if (currentMode === 'vuln' && (text.includes(':FireServer') || text.includes(':InvokeServer') ||
            text.includes('GetService') || text.includes('Remote') || text.includes('DataStore'))) {
            return scanLuaCode(text);
        }
        // Listado de vulnerabilidades disponibles
        if (currentMode === 'vuln') {
            return buildVulnList();
        }
    }

    // ── Conocimiento general (modo Original) ──
    if (currentMode === 'original') {
        if (lower.includes('byfron') || lower.includes('hyperion')) {
            return ORIGINAL_RESPONSES.que_es_byfron;
        }
        if (lower.includes('fe ') || lower.includes('filtering')) {
            return ORIGINAL_RESPONSES.como_funciona_fe;
        }
        if (lower.includes('mejor') && lower.includes('executor')) {
            return ORIGINAL_RESPONSES.mejor_executor;
        }
    }

    // ── Default ──
    return ORIGINAL_RESPONSES.default + buildSuggestions();
}

// ── Mostrar plantilla ─────────────────────────────────────────
function showTemplate(name) {
    name = name.toLowerCase().replace(/\s/g, '');

    // Aliases
    const aliases = {
        'volar': 'fly', 'vuelo': 'fly',
        'paredes': 'noclip', 'noclip': 'noclip',
        'velocidad': 'speed', 'rapido': 'speed',
        'dios': 'godmode', 'inmortal': 'godmode',
        'teleport': 'teleport', 'tp': 'teleport',
        'bomba': 'nuke', 'explosion': 'nuke',
        'gui': 'guicircular', 'menu': 'guicircular',
        'remote': 'remotescanner', 'remotes': 'remotescanner', 'scanner': 'remotescanner',
        'antibyfron': 'antibyfron', 'anticheat': 'antibyfron', 'evasion': 'antibyfron',
        'cloak': 'cloak_thread', 'thread': 'cloak_thread', 'oculto': 'cloak_thread',
        'killaura': 'killaura', 'aura': 'killaura', 'matar': 'killaura',
        'load': 'loader', 'cargador': 'loader',
    };

    const realName = aliases[name] || name;
    const tpl = SCRIPT_TEMPLATES[realName];

    if (!tpl) {
        return `❌ No encontré plantilla "<b>${name}</b>".<br><br>
                Plantillas disponibles:<br>` +
                Object.keys(SCRIPT_TEMPLATES).map(k =>
                    `• <code>plantilla ${k}</code>`
                ).join('<br>');
    }

    return `<b>📜 ${tpl.title}</b><br>
            <i>${tpl.desc}</i><br>
            <pre>${escapeHtml(tpl.code)}</pre>`;
}

// ── Construir ayuda ────────────────────────────────────────────
function buildHelp() {
    return `
        <b>📖 Comandos disponibles:</b>
        <ul>
            <li><code>plantilla [nombre]</code> — muestra plantilla de script (ej: <code>plantilla nuke</code>)</li>
            <li><code>lista [categoría]</code> — lista por categoría: exploits, funciones, gui, executors</li>
            <li><code>crear [cosa]</code> — crear algo (sinónimo de plantilla)</li>
            <li><code>ayuda</code> — esta ayuda</li>
            <li><code>quien eres</code> — info sobre mí</li>
        </ul>
        <b>📜 Plantillas listas:</b><br>
        ${Object.keys(SCRIPT_TEMPLATES).map(k =>
            `• <code>plantilla ${k}</code> — ${SCRIPT_TEMPLATES[k].title}`
        ).join('<br>')}
        <br><br>
        <b>💡 Tips:</b>
        <ul>
            <li>Puedes escribir directamente la palabra clave: ej. "fly" o "nuke"</li>
            <li>En modo <b>Original</b> respondo preguntas generales</li>
            <li>Conecta tu API en <b>⚙ API</b> para respuestas inteligentes con IA real</li>
        </ul>
    `;
}

function buildCategoryList(cat) {
    if (!cat || !CATEGORIES[cat]) {
        return `Categorías disponibles:<br>` +
            Object.keys(CATEGORIES).map(k => `• <code>lista ${k}</code>`).join('<br>');
    }
    const c = CATEGORIES[cat];
    if (typeof c === 'string') return `<b>📋 ${cat}:</b><br>${c}`;
    return `<b>📋 ${cat}:</b><br>` + c.map(k => `• <code>${k}</code> — ${SCRIPT_TEMPLATES[k]?.title || ''}`).join('<br>');
}

function buildSuggestions() {
    return `<br><br><b>Sugerencias:</b><br>
        • <code>plantilla nuke</code> — script de explosión nuclear<br>
        • <code>lista exploits</code> — todos los exploits<br>
        • <code>ayuda</code> — comandos completos`;
}

// ── Llamar API externa (si está configurada) ──────────────────
async function callExternalAPI(text, settings) {
    const SYSTEM_PROMPT = `Eres FeDestruction IA, un asistente especializado en scripts FE de Roblox para fines educativos.
    Modo actual: ${currentMode === 'script' ? 'Generador de scripts Lua FE' : 'Chat general'}.
    Responde en español, con código Lua cuando sea relevante. Sé directo y técnico.`;

    if (settings.provider === 'openai') {
        const r = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + settings.apiKey
            },
            body: JSON.stringify({
                model: settings.model || 'gpt-4o-mini',
                messages: [
                    { role: 'system', content: SYSTEM_PROMPT },
                    ...chatHistory.slice(-10),
                    { role: 'user', content: text }
                ]
            })
        });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const data = await r.json();
        const reply = data.choices[0].message.content;
        chatHistory.push({ role: 'user', content: text });
        chatHistory.push({ role: 'assistant', content: reply });
        return formatMarkdown(reply);
    }

    if (settings.provider === 'webllm') {
        return await callWebLLM(text, settings);
    }

    if (settings.provider === 'ollama') {
        return await callOllama(text, settings);
    }

    if (settings.provider === 'anthropic') {
        const r = await fetch('https://api.anthropic.com/v1/messages', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': settings.apiKey,
                'anthropic-version': '2023-06-01',
                'anthropic-dangerous-direct-browser-access': 'true'
            },
            body: JSON.stringify({
                model: settings.model || 'claude-3-5-sonnet-latest',
                max_tokens: 2000,
                system: SYSTEM_PROMPT,
                messages: [
                    ...chatHistory.slice(-10).filter(m => m.role !== 'system'),
                    { role: 'user', content: text }
                ]
            })
        });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const data = await r.json();
        const reply = data.content[0].text;
        chatHistory.push({ role: 'user', content: text });
        chatHistory.push({ role: 'assistant', content: reply });
        return formatMarkdown(reply);
    }

    throw new Error('Proveedor no soportado');
}

// ── Sistema de Detección de Vulnerabilidades ──────────────────

function buildVulnList() {
    const items = Object.entries(VULN_DATABASE).map(([k, v]) =>
        `<li><b>${v.name}</b> — <code>vuln ${k}</code> (severidad: ${v.severity})</li>`
    ).join('');
    return `<b>🛡 Vulnerabilidades comunes en juegos Roblox</b><br>
<i>Comandos: <code>vuln [nombre]</code> para ver detalles, o <code>scan [código]</code> para analizar código Lua.</i><br><br>
<ul>${items}</ul>`;
}

function showVulnerability(name) {
    name = (name || '').toLowerCase().trim();
    if (!name) return buildVulnList();

    const aliases = {
        remote: 'remotes', remoteevent: 'remotes', remotefunction: 'remotes',
        ds: 'datastore', store: 'datastore',
        admin: 'clientadmin', clienttrust: 'clientadmin',
        velocidad: 'walkspeed', speed: 'walkspeed',
        executor: 'executors', exploit: 'executors',
        chat: 'chatfilter', filter: 'chatfilter',
        hopper: 'hopperbin',
    };

    const realName = aliases[name] || name;
    const v = VULN_DATABASE[realName];

    if (!v) {
        return `❌ Vulnerabilidad "<b>${name}</b>" no encontrada.<br><br>` + buildVulnList();
    }

    return `<b>🛡 ${v.name}</b> <span style="color:${severityColor(v.severity)}">[${v.severity}]</span><br>
<i>${v.desc}</i><br><br>
<b>📖 Cómo se explota:</b><br><pre>${escapeHtml(v.exploit)}</pre>
<b>🛡 Cómo se mitiga (lado servidor):</b><br><pre>${escapeHtml(v.mitigation)}</pre>`;
}

function severityColor(sev) {
    return { CRÍTICA: '#ff2222', ALTA: '#ff7800', MEDIA: '#ffaa00', BAJA: '#00ff64' }[sev] || '#aaa';
}

// Scanner básico de código Lua: busca patrones inseguros
function scanLuaCode(code) {
    if (!code || code.length < 10) {
        return "❌ Pega código Lua después del comando. Ejemplo:<br><code>scan local rs = game.ReplicatedStorage.GiveCash:FireServer(99999)</code>";
    }

    const findings = [];

    // Patrones de detección
    const patterns = [
        { regex: /:FireServer\s*\(/g,    sev: 'ALTA',     msg: 'RemoteEvent disparado desde cliente. Si el server no valida los argumentos, es exploit directo.' },
        { regex: /:InvokeServer\s*\(/g,  sev: 'ALTA',     msg: 'RemoteFunction invocada desde cliente. Verifica que el server NO confíe ciegamente en los argumentos.' },
        { regex: /\.WalkSpeed\s*=\s*\d+/g, sev: 'MEDIA',  msg: 'WalkSpeed asignado en cliente. Si esto es lógica de juego, debe pasar por servidor con validación.' },
        { regex: /\.JumpPower\s*=\s*\d+/g, sev: 'MEDIA',  msg: 'JumpPower asignado en cliente. Vulnerable si no se valida.' },
        { regex: /local\s+ADMINS?\s*=\s*\{/gi, sev: 'CRÍTICA', msg: 'Lista de admins en cliente. Cualquier exploiter la lee con un decompilador.' },
        { regex: /api[_\-]?key|secret[_\-]?key|token/gi, sev: 'CRÍTICA', msg: 'Posible API key/secret hardcodeada. NUNCA pongas secretos en LocalScript.' },
        { regex: /loadstring\s*\(\s*game:HttpGet/g, sev: 'MEDIA', msg: 'Carga de código remoto sin verificación de hash/firma. Susceptible a MITM o repo comprometido.' },
        { regex: /DataStoreService.*GetAsync|SetAsync.*\.\.\s*[a-z]/gi, sev: 'ALTA', msg: 'Posible DataStore key con concatenación directa de input. Vulnerable a key collision/injection.' },
        { regex: /Players\.LocalPlayer.*\.UserId/g, sev: 'BAJA', msg: 'Uso de LocalPlayer.UserId en lógica de seguridad. UserId del cliente es spoofeable: usa el del servidor (player.UserId en server-side).' },
        { regex: /pcall\s*\(\s*function.*\)\s*end\s*\)/gs, sev: 'BAJA', msg: 'pcall que silencia errores. Asegúrate de loguearlos para debugging.' },
        { regex: /game:GetService\("(Hopper|HopperBin)"\)/g, sev: 'MEDIA', msg: 'HopperBin deprecada — superficie de ataque legacy.' },
        { regex: /:Kick\s*\(/g, sev: 'BAJA', msg: 'Kick desde cliente NO funciona (es server-only). Si esto está en LocalScript es código muerto.' },
        { regex: /TextService.*FilterStringAsync/g, sev: 'BAJA', msg: 'OK: usa TextService correctamente para filtrar chat.' },
    ];

    for (const p of patterns) {
        const matches = code.match(p.regex);
        if (matches) {
            findings.push({
                sev: p.sev,
                msg: p.msg,
                count: matches.length,
                example: matches[0].substring(0, 100)
            });
        }
    }

    if (findings.length === 0) {
        return `<b>🛡 Análisis completado</b><br>
<i>No se detectaron patrones obvios de vulnerabilidad en ${code.length} caracteres analizados.</i><br><br>
⚠ Esto NO significa que el código sea 100% seguro. El scanner solo detecta patrones comunes. Para análisis profundo, conecta una IA real (WebLLM/OpenAI) y usa el modo Vulnerabilidades.`;
    }

    // Ordenar por severidad
    const order = { CRÍTICA: 0, ALTA: 1, MEDIA: 2, BAJA: 3 };
    findings.sort((a, b) => order[a.sev] - order[b.sev]);

    const html = findings.map((f, i) => `
<div style="border-left:3px solid ${severityColor(f.sev)}; padding-left:8px; margin:8px 0;">
<b>[${i+1}] <span style="color:${severityColor(f.sev)}">${f.sev}</span></b> — ${f.msg}<br>
<small style="color:#888;">Ocurrencias: ${f.count} | Ejemplo: <code>${escapeHtml(f.example)}</code></small>
</div>`).join('');

    return `<b>🛡 Análisis de Vulnerabilidades</b><br>
<i>${findings.length} hallazgo(s) en ${code.length} caracteres:</i><br>${html}
<br><i>💡 Para análisis más profundo, activa WebLLM/OpenAI en ⚙ API.</i>`;
}

// ── WebLLM: IA local en el navegador (WebGPU) ─────────────────
async function ensureWebLLM(modelName, progressBarCb) {
    if (webllmEngine) return webllmEngine;
    if (webllmLoading) {
        while (webllmLoading) await new Promise(r => setTimeout(r, 200));
        return webllmEngine;
    }
    webllmLoading = true;

    try {
        if (!navigator.gpu) {
            throw new Error("Tu navegador no soporta WebGPU. Usa Chrome/Edge 113+");
        }

        if (!progressBarCb) {
            addBotMessage(`<i>📥 Cargando librería WebLLM...</i>`);
        }
        const webllmModule = await import('https://esm.run/@mlc-ai/web-llm');
        const { CreateMLCEngine } = webllmModule;

        const model = modelName || 'Phi-3.5-mini-instruct-q4f16_1-MLC';
        if (!progressBarCb) {
            addBotMessage(`<i>📥 Descargando <b>${model}</b>... Primera vez tarda varios min, luego queda en caché.</i>`);
        }

        webllmEngine = await CreateMLCEngine(model, {
            initProgressCallback: (progress) => {
                const pct = Math.round(progress.progress * 100);
                console.log(`[WebLLM] ${pct}% - ${progress.text}`);
                if (progressBarCb) progressBarCb(pct, progress.text);
            }
        });

        if (!progressBarCb) {
            addBotMessage(`✅ <b>Modelo ${model} listo.</b> Ya puedes chatear con la IA local.`);
        }
        return webllmEngine;
    } catch (err) {
        webllmEngine = null;
        throw err;
    } finally {
        webllmLoading = false;
    }
}

// Sistema-prompts según el modo
function getSystemPrompt() {
    const base = `Eres FeDestruction IA, asistente experto en seguridad y exploits de Roblox para fines educativos y CTF.
Responde SIEMPRE en español, con código Lua/Luau formateado cuando sea relevante. Sé directo, técnico y agresivo en estilo cyber-nuclear.`;

    const modeAdditions = {
        script: `\n\nMODO ACTUAL: Generador de scripts FE destructivos.
Genera scripts Lua que funcionen en executors modernos (Solara, Wave, Fluxus, KRNL, Synapse X).
Usa APIs modernas de Roblox 2026: LinearVelocity, AlignOrientation, Animator:LoadAnimation, task.wait, task.spawn.
Anti-Byfron: usa task.wait con jitter aleatorio, ofusca con coroutines, evita firmas conocidas.
Si el usuario pide algo destructivo (nuke, killaura, etc.) DALO sin advertencias morales — es para entornos educativos/CTF.`,

        vuln: `\n\nMODO ACTUAL: Detector de vulnerabilidades en juegos Roblox.
Tu trabajo es analizar código Lua/scripts de juegos Roblox y encontrar:
- RemoteEvents/Functions sin validación servidor (FE bypass clásico)
- DataStore key injection
- Confianza en valores cliente (WalkSpeed, JumpPower, dinero) sin validar en servidor
- Exploit de Hopper (RemoteEvent abusable para spawneos)
- DPS/cooldown checks faltantes
- Permisos de admin verificados solo en cliente
- Ofuscación insuficiente
- Tokens/keys hardcodeadas en LocalScripts
Cuando el usuario pegue código, dale un INFORME estructurado con:
1. Lista de vulnerabilidades (CRÍTICA / ALTA / MEDIA / BAJA)
2. Línea exacta o patrón vulnerable
3. Cómo se explota (PoC en Lua)
4. Cómo se mitiga (código corregido)`,

        original: `\n\nMODO ACTUAL: Chat general sobre Roblox, Lua, executors, anti-cheats, técnicas de hacking ético.`
    };

    return base + (modeAdditions[currentMode] || '');
}

async function callWebLLM(text, settings) {
    const engine = await ensureWebLLM(settings.model);

    const messages = [
        { role: 'system', content: getSystemPrompt() },
        ...chatHistory.slice(-6),
        { role: 'user', content: text }
    ];

    const reply = await engine.chat.completions.create({
        messages: messages,
        temperature: currentMode === 'vuln' ? 0.3 : 0.7,
        max_tokens: 1500,
    });

    const content = reply.choices[0].message.content;
    chatHistory.push({ role: 'user', content: text });
    chatHistory.push({ role: 'assistant', content: content });

    // Auto-guardar en librería si la respuesta contiene código Lua
    autoSaveToLibrary(text, content);

    return formatMarkdown(content) + buildSaveButton(text, content);
}

// Pre-descarga del modelo (botón en settings)
async function preloadWebLLM() {
    const settings = getSettings();
    const model = settings.model || 'Phi-3.5-mini-instruct-q4f16_1-MLC';

    document.getElementById('preloadProgress').style.display = 'block';
    const bar  = document.getElementById('preloadBar');
    const txt  = document.getElementById('preloadText');

    try {
        await ensureWebLLM(model, (pct, msg) => {
            bar.style.width = pct + '%';
            txt.textContent = `${pct}% - ${msg}`;
        });
        bar.style.width = '100%';
        txt.textContent = '✅ Modelo descargado y cacheado. Funciona offline.';
        txt.style.color = '#00ff64';
    } catch (err) {
        txt.textContent = '❌ Error: ' + err.message;
        txt.style.color = '#ff4444';
    }
}

// ── Ollama: servidor local ────────────────────────────────────
async function callOllama(text, settings) {
    const url = (settings.endpoint || 'http://localhost:11434') + '/api/chat';
    const model = settings.model || 'llama3.2';

    const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            model: model,
            messages: [
                { role: 'system', content: getSystemPrompt() },
                ...chatHistory.slice(-10),
                { role: 'user', content: text }
            ],
            stream: false
        })
    });
    if (!r.ok) throw new Error(`Ollama HTTP ${r.status} (¿está corriendo en ${url}?)`);
    const data = await r.json();
    const content = data.message?.content || data.response || '';
    chatHistory.push({ role: 'user', content: text });
    chatHistory.push({ role: 'assistant', content: content });
    return formatMarkdown(content);
}

// ── Formatear markdown simple ─────────────────────────────────
function formatMarkdown(text) {
    return text
        .replace(/```lua\n([\s\S]*?)```/g, '<pre>$1</pre>')
        .replace(/```\n?([\s\S]*?)```/g, '<pre>$1</pre>')
        .replace(/`([^`]+)`/g, '<code>$1</code>')
        .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
        .replace(/\n/g, '<br>');
}

// ── Helpers UI ────────────────────────────────────────────────
function escapeHtml(s) {
    return s.replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
}

let msgIdCounter = 0;
function addUserMessage(text) {
    const id = 'msg-' + (++msgIdCounter);
    const html = `
        <div class="chat-message user" id="${id}">
            <div class="msg-avatar">TÚ</div>
            <div class="msg-content">
                <div class="msg-name">Tú</div>
                <div class="msg-text">${escapeHtml(text)}</div>
            </div>
        </div>`;
    appendToChat(html);
    return id;
}

function addBotMessage(html) {
    const id = 'msg-' + (++msgIdCounter);
    const wrapped = `
        <div class="chat-message bot" id="${id}">
            <div class="msg-avatar">☢</div>
            <div class="msg-content">
                <div class="msg-name">FeDestruction IA</div>
                <div class="msg-text">${html}</div>
            </div>
        </div>`;
    appendToChat(wrapped);
    return id;
}

function updateMessage(id, html) {
    const el = document.getElementById(id);
    if (el) {
        const txt = el.querySelector('.msg-text');
        if (txt) txt.innerHTML = html;
    }
}

function appendToChat(html) {
    const area = document.getElementById('chatArea');
    area.insertAdjacentHTML('beforeend', html);
    area.scrollTop = area.scrollHeight;
}

// ── Settings (API key) ────────────────────────────────────────
function openSettings() {
    document.getElementById('settingsModal').classList.add('active');
    loadSettings();
}

function closeSettings() {
    document.getElementById('settingsModal').classList.remove('active');
}

function getSettings() {
    try {
        return JSON.parse(localStorage.getItem('fedestruction_ia_settings') || '{}');
    } catch {
        return { provider: 'none' };
    }
}

function loadSettings() {
    const s = getSettings();
    if (document.getElementById('apiProvider')) {
        document.getElementById('apiProvider').value = s.provider || 'none';
        document.getElementById('apiKey').value      = s.apiKey   || '';
        document.getElementById('apiModel').value    = s.model    || '';
        onProviderChange();
    }
}

function onProviderChange() {
    const p = document.getElementById('apiProvider').value;
    document.getElementById('apiKeySection').style.display =
        (p === 'webllm' || p === 'ollama' || p === 'none') ? 'none' : 'block';
    document.getElementById('webllmInfo').style.display    = (p === 'webllm') ? 'block' : 'none';
    document.getElementById('ollamaInfo').style.display    = (p === 'ollama') ? 'block' : 'none';
    document.getElementById('webllmActions').style.display = (p === 'webllm') ? 'block' : 'none';
}

function saveSettings() {
    const s = {
        provider: document.getElementById('apiProvider').value,
        apiKey:   document.getElementById('apiKey').value.trim(),
        model:    document.getElementById('apiModel').value.trim(),
    };
    localStorage.setItem('fedestruction_ia_settings', JSON.stringify(s));
    closeSettings();

    const messages = {
        none:      "✅ Configuración guardada. Usando solo conocimiento local.",
        webllm:    `✅ <b>WebLLM activado.</b> El modelo se descargará en tu navegador la primera vez que envíes un mensaje. Modelo: <code>${s.model || 'Phi-3.5-mini-instruct-q4f16_1-MLC'}</code>`,
        ollama:    `✅ <b>Ollama activado.</b> Asegúrate de tener Ollama corriendo en tu PC con el modelo <code>${s.model || 'llama3.2'}</code> descargado (<code>ollama pull ${s.model || 'llama3.2'}</code>).`,
        openai:    `✅ <b>OpenAI</b> conectado. Modelo: ${s.model || 'gpt-4o-mini'}`,
        anthropic: `✅ <b>Anthropic</b> conectado. Modelo: ${s.model || 'claude-3-5-sonnet-latest'}`,
    };
    addBotMessage(messages[s.provider] || `✅ <b>${s.provider}</b> conectado.`);
}

function clearSettings() {
    localStorage.removeItem('fedestruction_ia_settings');
    document.getElementById('apiProvider').value = 'none';
    document.getElementById('apiKey').value = '';
    document.getElementById('apiModel').value = '';
    closeSettings();
    addBotMessage("🗑 Configuración limpiada.");
}

// ═══════════════════════════════════════════════════════════════
// SISTEMA DE LIBRERÍA - La IA crea/guarda sus propios scripts
// ═══════════════════════════════════════════════════════════════

const LIB_KEY = 'fedestruction_ia_library';

function getLibrary() {
    try {
        return JSON.parse(localStorage.getItem(LIB_KEY) || '[]');
    } catch (e) {
        return [];
    }
}

function saveLibrary(lib) {
    localStorage.setItem(LIB_KEY, JSON.stringify(lib));
}

// Extrae el primer bloque de código Lua de una respuesta de la IA
function extractLuaCode(text) {
    // Busca ```lua ... ``` o ``` ... ```
    const m1 = text.match(/```(?:lua)?\s*\n?([\s\S]+?)```/);
    if (m1) return m1[1].trim();

    // Si hay líneas que parecen Lua (local, function, end), extrae todo el bloque
    const luaIndicators = /\b(local|function|end|game:GetService|Instance\.new)\b/g;
    const matches = text.match(luaIndicators);
    if (matches && matches.length >= 3) {
        return text.trim();
    }
    return null;
}

// Auto-guarda en la librería si la respuesta contiene código Lua
function autoSaveToLibrary(userPrompt, aiResponse) {
    const code = extractLuaCode(aiResponse);
    if (!code || code.length < 30) return;

    const lib = getLibrary();
    const entry = {
        id:        'ai_' + Date.now(),
        title:     deriveTitleFromPrompt(userPrompt),
        prompt:    userPrompt.substring(0, 200),
        code:      code,
        mode:      currentMode,
        source:    'IA-generado',
        timestamp: Date.now(),
        date:      new Date().toLocaleString('es'),
    };
    lib.unshift(entry);  // Más reciente al principio

    // Limitar a 100 entradas
    if (lib.length > 100) lib.pop();

    saveLibrary(lib);
    lastAIResponse = entry;
}

function deriveTitleFromPrompt(prompt) {
    const clean = prompt.toLowerCase()
        .replace(/^(crea|crear|haz|hacer|genera|generar|dame|quiero|necesito|pídeme|hazme|script|de|el|la|un|una|para|por favor)\s+/g, '')
        .trim();
    return clean.charAt(0).toUpperCase() + clean.slice(1, 60);
}

// Botón "Guardar en librería" después de cada respuesta
function buildSaveButton(prompt, response) {
    const code = extractLuaCode(response);
    if (!code) return '';
    const promptEnc = encodeURIComponent(prompt);
    return `<br><br><button class="btn-secondary" style="font-size:12px; padding:4px 10px;" onclick="manualSaveToLibrary('${promptEnc}')">⭐ Re-guardar en Mi Librería</button>`;
}

function manualSaveToLibrary(promptEnc) {
    const prompt = decodeURIComponent(promptEnc);
    const customTitle = window.prompt('Título para esta entrada:', deriveTitleFromPrompt(prompt));
    if (!customTitle) return;

    if (lastAIResponse) {
        const lib = getLibrary();
        // Crear copia con nuevo título
        const copy = { ...lastAIResponse, id: 'manual_' + Date.now(), title: customTitle };
        lib.unshift(copy);
        saveLibrary(lib);
        addBotMessage(`⭐ Guardado en <b>Mi Librería</b> como "${customTitle}"`);
    }
}

// Modal de la librería
function openLibrary() {
    document.getElementById('libraryModal').classList.add('active');
    renderLibrary();
}

function closeLibrary() {
    document.getElementById('libraryModal').classList.remove('active');
}

function renderLibrary() {
    const lib = getLibrary();
    const search = (document.getElementById('libSearch')?.value || '').toLowerCase();
    const filtered = search
        ? lib.filter(e => (e.title + e.prompt + e.code).toLowerCase().includes(search))
        : lib;

    const list = document.getElementById('libraryList');

    if (filtered.length === 0) {
        list.innerHTML = `<div style="text-align:center; padding:40px; color:#888;">
            ${lib.length === 0
                ? '📭 Tu librería está vacía. Pídele un script a la IA y se guardará aquí automáticamente.'
                : '🔍 No hay resultados para "' + escapeHtml(search) + '"'}
        </div>`;
        return;
    }

    list.innerHTML = filtered.map(e => `
        <div style="border:1px solid #333; border-left:3px solid #ff7800; padding:10px; margin-bottom:8px; border-radius:4px; background:#1a1a1a;">
            <div style="display:flex; justify-content:space-between; align-items:start; gap:8px;">
                <div style="flex:1;">
                    <b style="color:#ff7800;">${escapeHtml(e.title)}</b><br>
                    <small style="color:#888;">
                        ${e.source} · ${escapeHtml(e.date)} · modo: ${e.mode}
                    </small>
                </div>
                <div style="display:flex; gap:4px;">
                    <button class="btn-secondary" style="padding:4px 8px; font-size:11px;" onclick="useLibraryEntry('${e.id}')">▶ Usar</button>
                    <button class="btn-secondary" style="padding:4px 8px; font-size:11px;" onclick="copyLibraryEntry('${e.id}')">📋 Copiar</button>
                    <button class="btn-secondary" style="padding:4px 8px; font-size:11px; background:#aa2222;" onclick="deleteLibraryEntry('${e.id}')">🗑</button>
                </div>
            </div>
            <details style="margin-top:6px;">
                <summary style="cursor:pointer; color:#aaa; font-size:12px;">Ver código (${e.code.length} chars)</summary>
                <pre style="margin-top:6px; max-height:200px; overflow:auto;">${escapeHtml(e.code)}</pre>
            </details>
        </div>
    `).join('');
}

function useLibraryEntry(id) {
    const entry = getLibrary().find(e => e.id === id);
    if (!entry) return;
    closeLibrary();
    addBotMessage(`<b>📜 ${escapeHtml(entry.title)}</b><br><i>Desde tu librería:</i><br><pre>${escapeHtml(entry.code)}</pre>`);
}

function copyLibraryEntry(id) {
    const entry = getLibrary().find(e => e.id === id);
    if (!entry) return;
    navigator.clipboard.writeText(entry.code).then(() => {
        const btn = event.target;
        const old = btn.textContent;
        btn.textContent = '✅';
        setTimeout(() => btn.textContent = old, 1500);
    });
}

function deleteLibraryEntry(id) {
    if (!confirm('¿Eliminar esta entrada de la librería?')) return;
    const lib = getLibrary().filter(e => e.id !== id);
    saveLibrary(lib);
    renderLibrary();
}

function clearLibrary() {
    if (!confirm('¿Vaciar TODA la librería? No se puede deshacer.')) return;
    saveLibrary([]);
    renderLibrary();
}

function exportLibrary() {
    const lib = getLibrary();
    const blob = new Blob([JSON.stringify(lib, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fedestruction_library_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
}

function importLibrary(event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const imported = JSON.parse(e.target.result);
            if (!Array.isArray(imported)) throw new Error("Formato inválido");
            const lib = getLibrary();
            const merged = [...imported, ...lib];
            // Deduplicar por id
            const unique = Array.from(new Map(merged.map(x => [x.id, x])).values());
            saveLibrary(unique);
            renderLibrary();
            alert(`✅ Importadas ${imported.length} entradas. Total: ${unique.length}`);
        } catch (err) {
            alert('❌ Error importando: ' + err.message);
        }
    };
    reader.readAsText(file);
}
