#!/usr/bin/env python3
"""
FeDestruction IA - Launcher
Inicia un servidor HTTP local y abre la app en el navegador.
Funciona en Windows, Mac, Linux. Se puede empaquetar como .exe con PyInstaller.

Uso:
    python launcher.py            # abre en navegador
    python launcher.py --port 8080
    python launcher.py --no-browser   # solo servidor
"""

import http.server
import socketserver
import webbrowser
import os
import sys
import socket
import threading
import argparse
from pathlib import Path

# ── Configuración ────────────────────────────────────────────────
DEFAULT_PORT = 8765
APP_NAME     = "FeDestruction IA"
APP_VERSION  = "1.0 OfEnd"

# Directorio base (funciona compilado con PyInstaller)
if getattr(sys, 'frozen', False):
    BASE_DIR = Path(sys._MEIPASS)
else:
    BASE_DIR = Path(__file__).parent

os.chdir(BASE_DIR)


def find_free_port(start=8765):
    """Encuentra un puerto libre comenzando desde start."""
    for port in range(start, start + 100):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("127.0.0.1", port))
                return port
        except OSError:
            continue
    return start


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    """HTTP Handler silencioso (no spamea la consola)."""
    def log_message(self, format, *args):
        pass

    def end_headers(self):
        # Anti-cache para desarrollo
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()


def print_banner(port):
    banner = f"""
╔══════════════════════════════════════════════════════════╗
║          ☢ {APP_NAME} v{APP_VERSION}                   
║                                                          ║
║    Asistente local para Scripts Roblox FE                ║
║    Servidor: http://127.0.0.1:{port:<5}                       ║
║                                                          ║
║    ▶ Cierra esta ventana para detener la app             ║
║    ▶ Si el navegador no abre: visita la URL manualmente  ║
╚══════════════════════════════════════════════════════════╝
"""
    print(banner)


def main():
    parser = argparse.ArgumentParser(description=APP_NAME)
    parser.add_argument('--port', type=int, default=DEFAULT_PORT, help='Puerto HTTP')
    parser.add_argument('--no-browser', action='store_true', help='No abrir navegador')
    parser.add_argument('--host', default='0.0.0.0', help='Host (default: 0.0.0.0 para Replit)')
    args = parser.parse_args()

    # Si se especifica explícitamente, usar ese puerto. Si no, buscar libre.
    port = args.port if args.port != DEFAULT_PORT else find_free_port(args.port)
    print_banner(port)

    # Iniciar servidor HTTP
    try:
        with socketserver.TCPServer((args.host, port), QuietHandler) as httpd:
            url = f"http://{args.host}:{port}/index.html"

            # Abrir navegador en thread separado para no bloquear
            if not args.no_browser:
                def open_browser():
                    import time
                    time.sleep(0.5)
                    try:
                        webbrowser.open(url)
                    except Exception as e:
                        print(f"[!] No pude abrir el navegador: {e}")
                        print(f"    Abre manualmente: {url}")
                threading.Thread(target=open_browser, daemon=True).start()

            print(f"[OK] Servidor iniciado en {url}")
            print("[OK] Presiona Ctrl+C para detener\n")
            httpd.serve_forever()

    except KeyboardInterrupt:
        print("\n[OK] Servidor detenido. ¡Hasta luego!")
    except Exception as e:
        print(f"[ERROR] {e}")
        input("Presiona Enter para cerrar...")
        sys.exit(1)


if __name__ == "__main__":
    main()
